# ionic-firebase chat app part 1
 ### Ionic Chat App using Firebase - Part 1
 
 Watch the Full Episode on YouTube at https://youtu.be/9QQX1T8u4DA

<img src="https://github.com/Nykz/ionic-firebase-chat-app-1/blob/main/Snapshot_2022-11-28-19.45.09.jpg" width="850" height="500" />
