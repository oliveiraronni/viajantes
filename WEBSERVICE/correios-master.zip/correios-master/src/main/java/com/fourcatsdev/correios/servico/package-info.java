@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://cliente.bean.master.sigep.bsb.correios.com.br/")
package com.fourcatsdev.correios.servico;
